// Draw the spending donut with SVG paths, labels, accessible selection and floating-slice feedback. Angles use radians; chart coordinates are SVG viewBox units.
// Rebuild the donut from category totals and call onSelect when a slice is chosen.
function drawSpendingChart(chartSvg, totals, onSelect, options={}) {
  const chartColors=options.colors||categories;
  const selectedName=options.selectedCategory||selectedCategory;
  const svgNamespace = 'http://www.w3.org/2000/svg';
  const total = Object.values(totals).reduce((sum, amount) => sum + amount, 0);
  chartSvg.replaceChildren();
  chartSvg.setAttribute('aria-label', `${options.label||'Spending by category'}. ${Object.entries(totals).map(([name, amount]) => `${name}: ${formatMoney(amount)}, ${formatPercentage(amount, total)}`).join('. ')}`);
  const element = (tag, attributes) => {
    const node = document.createElementNS(svgNamespace, tag);
    Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, value));
    return node;
  };
  const point = (radius, angle) => [220 + radius * Math.cos(angle), 200 + radius * Math.sin(angle)];
  chartSvg.append(element('circle', {cx:220, cy:200, r:108, fill:'none', stroke:'var(--subtle)', 'stroke-width':44}));
  let angle = -Math.PI / 2;
  const labels = [];
  let liftedPiece = null;
  Object.entries(totals).forEach(([name, amount]) => {
    if (!amount || !total) return;
    const sweep = amount / total * Math.PI * 2;
    const gap = Math.min(0.025, sweep / 10);
    const start = angle + gap / 2, end = angle + sweep - gap / 2, middle = angle + sweep / 2;
    const selected = name === selectedName;
    const liftX = Math.cos(middle) * 12;
    const liftY = Math.sin(middle) * 12 - 16;
    const outerRadius = 129, innerRadius = 86;
    const outerStartPoint = point(outerRadius, start), outerEndPoint = point(outerRadius, end), innerEndPoint = point(innerRadius, end), innerStartPoint = point(innerRadius, start);
    const largeArcFlag = end - start > Math.PI ? 1 : 0;
    const path = element('path', {
      d:`M ${outerStartPoint} A ${outerRadius} ${outerRadius} 0 ${largeArcFlag} 1 ${outerEndPoint} L ${innerEndPoint} A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 0 ${innerStartPoint} Z`,
      fill:chartColors[name], class:'chart-slice', role:'button', tabindex:0,
      'data-category':name, 'aria-pressed':String(name === selectedName),
      'aria-label':`${name}: ${formatMoney(amount)}, ${formatPercentage(amount, total)}`,
    });
    const title = element('title', {}); title.textContent = `${name} · ${formatPercentage(amount, total)} · ${formatMoney(amount)}`; path.append(title);
    const layer = element('g', {class:'slice-layer'});
    const piece = element('g', {class:`slice-piece${selected ? ' is-selected' : ''}`});
    piece.style.setProperty('--lift-x', `${liftX}px`);
    piece.style.setProperty('--lift-y', `${liftY}px`);
    piece.style.setProperty('--slice-color', chartColors[name]);
    // A stationary hit area prevents hover flicker when the visible slice lifts.
    layer.append(element('path', {d:path.getAttribute('d'), fill:'transparent', class:'slice-hit', 'aria-hidden':'true'}),piece);
    piece.append(element('path', {d:path.getAttribute('d'), fill:chartColors[name], class:'slice-halo', 'aria-hidden':'true'}));
    layer.addEventListener('pointerenter', (event) => {
      if (event.pointerType !== 'touch') piece.classList.add('is-hovered');
    });
    layer.addEventListener('pointerleave', () => piece.classList.remove('is-hovered'));
    const activate = () => {
      const focused = document.activeElement === path;
      if(!options.independent)selectedCategory = name; onSelect(name);
      if (focused) [...chartSvg.querySelectorAll('[data-category]')].find(node=>node.dataset.category===name)?.focus();
    };
    layer.addEventListener('click', activate);
    path.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); activate(); }
    });
    piece.append(path);
    if (selected) liftedPiece = layer;
    else chartSvg.append(layer);
    const right = Math.cos(middle) >= 0;
    labels.push({name, amount, right, middle, liftX:selected ? liftX : 0, liftY:selected ? liftY : 0, y:point(155,middle)[1]});
    if (amount / total >= 0.09) {
      const location = point(107,middle);
      const percent = element('text', {x:location[0], y:location[1], class:'slice-percent', 'text-anchor':'middle', 'dominant-baseline':'middle', fill:name === 'Food' || name === 'Transport' ? '#263e10' : '#fff', 'aria-hidden':'true'});
      percent.textContent = formatPercentage(amount,total); piece.append(percent);
    }
    angle += sweep;
  });
  // Paint the raised slice last so its glow and shadow sit above the other slices.
  if (liftedPiece) chartSvg.append(liftedPiece);
  // Keep labels for small adjacent slices apart, with leader lines to their slice.
  for (const right of [false, true]) {
    const side = labels.filter((label) => label.right === right).sort((firstLabel,secondLabel) => firstLabel.y - secondLabel.y);
    side.forEach((label,index) => { label.y = Math.max(30, label.y, index ? side[index-1].y + 40 : 30); });
    for (let index = side.length-1; index >= 0; index--) side[index].y = Math.min(side[index].y, index === side.length-1 ? 365 : side[index+1].y - 40);
    side.forEach((label) => {
      const edge = point(138,label.middle).map((value,index)=>value+(index ? label.liftY : label.liftX)), x = right ? 357 : 83;
      chartSvg.append(element('polyline', {points:`${edge} ${right ? 345 : 95},${label.y} ${right ? 353 : 87},${label.y}`, fill:'none', stroke:'var(--input-border)', 'stroke-width':1.3, 'aria-hidden':'true'}));
      const text = element('text', {x, y:label.y-3, class:'chart-label', 'text-anchor':right ? 'start' : 'end', 'aria-hidden':'true'});
      const name = element('tspan', {x, dy:0}); name.textContent = label.name.length>18?label.name.slice(0,17)+'…':label.name;
      const percent = element('tspan', {x, dy:18, class:'chart-label-percent'}); percent.textContent = formatPercentage(label.amount,total);
      text.append(name,percent); chartSvg.append(text);
    });
  }
}
